module.exports = [
    {
        "id": 1,
        "tila": "käytetty",
        "valmistaja": "",
        "tyyppi": "",
        "koko": "",
        "vuosimalli": 2010,
        "materiaali": ""
    },
    {
        "id": 2,
        "tila": "uusi",
        "valmistaja": "",
        "tyyppi": "",
        "koko": "",
        "vuosimalli": 2012,
        "materiaali": ""
    },
    {
        "id": 3,
        "tila": "uusi",
        "valmistaja": "",
        "tyyppi": "",
        "koko": "",
        "vuosimalli": 2009,
        "materiaali": ""
    }
];