module.exports = [
    {
        "id": 1,
        "ilmJattaja": "Matti Meikäläinen",
        "ilmPvm": "6.11.2018",
        "ilmTila": "Myynnissä",
        "hinta": 2500,
        "pyora": {
            "id": 1,
            "tila": "käytetty",
            "valmistaja": "",
            "tyyppi": "",
            "koko": "",
            "vuosimalli": 2010,
            "materiaali": ""
        }
    },
    {
        "id": 2,
        "ilmJattaja": "Maija Meikäläinen",
        "ilmPvm": "6.10.2018",
        "ilmTila": "Myynnissä",
        "hinta": 2700,
        "pyora": {
            "id": 2,
            "tila": "uusi",
            "valmistaja": "",
            "tyyppi": "",
            "koko": "",
            "vuosimalli": 2012,
            "materiaali": ""
        }
    },
    {
        "id": 3,
        "ilmJattaja": "Teppo Teikäläinen",
        "ilmPvm": "16.10.2018",
        "ilmTila": "Myyty",
        "hinta": 2200,
        "pyora": {
            "id": 3,
            "tila": "uusi",
            "valmistaja": "",
            "tyyppi": "",
            "koko": "",
            "vuosimalli": 2009,
            "materiaali": ""
        }
    }

];